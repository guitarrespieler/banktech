package artificialintelligence.neuralnetwork;

public enum NodeType {
	InputLayer,HiddenLayer,OutputLayer
}
