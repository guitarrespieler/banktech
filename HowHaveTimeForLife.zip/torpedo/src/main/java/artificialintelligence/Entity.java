package artificialintelligence;

public class Entity implements Comparable<Entity>{

	public Entity() {
		// TODO Auto-generated constructor stub
	}

	public int compareTo(Entity o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
